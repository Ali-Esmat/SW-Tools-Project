package com.project.enums;

public enum OrderStatus {
    PREPARING, 
    DELIVERED, 
    CANCELED
}
