package com.project.enums;

public enum RunnerStatus {
    AVAILABLE, 
    BUSY
}
